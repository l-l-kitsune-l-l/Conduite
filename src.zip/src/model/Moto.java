package model;

public class Moto extends Vehicule {
    public Moto() {
        super(220, 25, 15, 10); // vitesse max 220, accel 25, frein 15, ralentir 10
    }
}
