package model;

public class Auto extends Vehicule {
    public Auto() {
        super(180, 15, 20, 5); // vitesse max 180, accel 15, frein 20, ralentir 5
    }
}
