package model;

public class Velo extends Vehicule {
    public Velo() {
        super(40, 5, 10, 3); // vitesse max 40, accel 5, frein 10, ralentir 3
    }
}
